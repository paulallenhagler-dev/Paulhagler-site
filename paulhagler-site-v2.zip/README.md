# paulhagler.com

Current front-facing site: one-page AI consulting site.

The previous experimental art portal is preserved at `portal.html` for later development,
but it is intentionally not linked from the consulting homepage.

Sections on the live homepage:
- AI consulting hero
- approach
- selected work (Longboards, Equip-Bid, Monarch Liquidation)
- $650 AI Operations Audit
- about / credibility
- contact

Visual direction:
ultra-minimal, dark, restrained green, with subtle KLAAT-inspired signal geometry.

Deployment:
Render static site from this ZIP package.
