# paulhagler.com

Static personal site for Paul Hagler.

Current sections:
- Portal homepage
- AI consulting
- Selected work / case studies
- About / CV
- Atelier KLAAT
- Contact
- KLAAT external portal

Deployment note:
The current production deployment is a Render static site. The custom domain is presently forwarded from GoDaddy to the Render URL; direct custom-domain binding can be added later.
